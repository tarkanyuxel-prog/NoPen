import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const NoPenApp());

const cyan = Color(0xFF5CE3FC), magenta = Color(0xFFEE48B8), lime = Color(0xFFB9FC51), bg = Color(0xFF11131D);

class NoPenApp extends StatelessWidget {
  const NoPenApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'NoPen',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: cyan, brightness: Brightness.dark),
      cardTheme: CardThemeData(color: const Color(0xFF191D2A), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    ),
    home: const Shell(),
  );
}

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState()=>_ShellState(); }
class _ShellState extends State<Shell> {
  int index=0;
  final pages=const [HomePage(), MeetingsPage(), ActionsPage(), AskAiPage(), SettingsPage()];
  @override Widget build(BuildContext context)=>Scaffold(
    body: SafeArea(child: pages[index]),
    bottomNavigationBar: NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:const [
      NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Ana Sayfa'),
      NavigationDestination(icon:Icon(Icons.event_note_outlined),label:'Toplantılar'),
      NavigationDestination(icon:Icon(Icons.task_alt),label:'Aksiyonlar'),
      NavigationDestination(icon:Icon(Icons.auto_awesome),label:'AI'),
      NavigationDestination(icon:Icon(Icons.settings_outlined),label:'Ayarlar'),
    ]),
  );
}

class PageTitle extends StatelessWidget { final String title; final String? sub; const PageTitle(this.title,{this.sub,super.key});
  @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.fromLTRB(20,20,20,10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w800)),if(sub!=null)...[const SizedBox(height:4),Text(sub!,style:const TextStyle(color:Colors.white60))]])); }

class HomePage extends StatelessWidget { const HomePage({super.key});
  @override Widget build(BuildContext context)=>ListView(children:[
    const PageTitle('NoPen',sub:'Toplantı Biter. Sonuç Kalır.'),
    Padding(padding:const EdgeInsets.all(16),child:Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Row(children:[Icon(Icons.calendar_month,color:cyan),SizedBox(width:8),Text('Yaklaşan Toplantı',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))]),
      const SizedBox(height:14),const Text('Outlook takvimini bağlayın',style:TextStyle(fontSize:20,fontWeight:FontWeight.w700)),
      const SizedBox(height:6),const Text('Calendars.Read ile bugünkü toplantılar burada görünecek.',style:TextStyle(color:Colors.white60)),
      const SizedBox(height:16),FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SetupPage())),icon:const Icon(Icons.add),label:const Text('Yeni Toplantı')),
    ]))),
    const Padding(padding:EdgeInsets.symmetric(horizontal:20),child:Text('Bugünkü Toplantılar',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold))),
    const Padding(padding:EdgeInsets.all(20),child:Text('Microsoft hesabı bağlandığında Outlook takvimi otomatik listelenecek.',style:TextStyle(color:Colors.white54))),
  ]);
}

class SetupPage extends StatefulWidget { const SetupPage({super.key}); @override State<SetupPage> createState()=>_SetupPageState(); }
class _SetupPageState extends State<SetupPage>{
 final title=TextEditingController(),subject=TextEditingController(),person=TextEditingController(),role=TextEditingController(); final List<String> people=[];
 void add(){final n=person.text.trim();if(n.isEmpty)return;setState((){people.add(role.text.trim().isEmpty?n:'$n — ${role.text.trim()}');person.clear();role.clear();});}
 @override void dispose(){title.dispose();subject.dispose();person.dispose();role.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Toplantı Hazırlığı')),body:ListView(padding:const EdgeInsets.all(20),children:[
  TextField(controller:title,decoration:const InputDecoration(labelText:'Toplantı adı',border:OutlineInputBorder())),const SizedBox(height:12),
  TextField(controller:subject,decoration:const InputDecoration(labelText:'Konu / Açıklama',border:OutlineInputBorder())),const SizedBox(height:20),
  const Text('Katılımcılar',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:8),
  TextField(controller:person,decoration:const InputDecoration(labelText:'Ad Soyad',border:OutlineInputBorder())),const SizedBox(height:8),
  Row(children:[Expanded(child:TextField(controller:role,decoration:const InputDecoration(labelText:'Görev / Unvan (isteğe bağlı)',border:OutlineInputBorder()))),const SizedBox(width:8),IconButton.filled(onPressed:add,icon:const Icon(Icons.add))]),
  ...people.asMap().entries.map((e)=>Card(child:ListTile(title:Text(e.value),trailing:IconButton(icon:const Icon(Icons.close),onPressed:()=>setState(()=>people.removeAt(e.key)))))),
  const SizedBox(height:20),FilledButton.icon(onPressed:(){final n=title.text.trim().isEmpty?'Yeni Toplantı':title.text.trim();Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>LiveMeetingPage(title:n,people:List.of(people))));},icon:const Icon(Icons.play_arrow),label:const Padding(padding:EdgeInsets.all(15),child:Text('Toplantıyı Başlat')))
 ]));
}

class LiveMeetingPage extends StatefulWidget { final String title;final List<String> people;const LiveMeetingPage({super.key,required this.title,required this.people});@override State<LiveMeetingPage> createState()=>_LiveMeetingPageState(); }
class _LiveMeetingPageState extends State<LiveMeetingPage> with SingleTickerProviderStateMixin{
 final speech=stt.SpeechToText();late AnimationController anim;Timer? timer;int seconds=0;bool listening=false;String transcript='';double level=0;
 @override void initState(){super.initState();anim=AnimationController(vsync:this,duration:const Duration(seconds:14))..repeat();_start();}
 Future<void> _start()async{final ok=await speech.initialize();if(!mounted)return;if(ok){setState(()=>listening=true);timer=Timer.periodic(const Duration(seconds:1),(_){if(mounted)setState(()=>seconds++);});await speech.listen(onResult:(r){if(mounted)setState(()=>transcript=r.recognizedWords);},onSoundLevelChange:(v){if(mounted)setState(()=>level=v);},listenOptions:stt.SpeechListenOptions(partialResults:true,cancelOnError:false));}}
 String get clock=>'${(seconds~/3600).toString().padLeft(2,'0')}:${((seconds%3600)~/60).toString().padLeft(2,'0')}:${(seconds%60).toString().padLeft(2,'0')}';
 Future<void> finish()async{await speech.stop();timer?.cancel();if(!mounted)return;Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ProcessingPage(title:widget.title,people:widget.people,transcript:transcript)));}
 @override void dispose(){timer?.cancel();speech.stop();anim.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.title)),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
  const SizedBox(height:8),const Text('Toplantı Dinleniyor',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const Text('Ses kaydedilmez • Canlı transkript',style:TextStyle(color:Colors.white54)),
  const Spacer(),AnimatedBuilder(animation:anim,builder:(_,__)=>CustomPaint(size:const Size(240,240),painter:PlanetPainter(anim.value,level))),
  const SizedBox(height:20),Text(clock,style:const TextStyle(fontSize:36,fontWeight:FontWeight.w800)),Text(listening?'● Dinliyor...':'Mikrofon hazırlanıyor...',style:TextStyle(color:listening?lime:Colors.white60)),
  const SizedBox(height:16),Container(height:130,width:double.infinity,padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.05),borderRadius:BorderRadius.circular(16)),child:SingleChildScrollView(child:Text(transcript.isEmpty?'Konuşma bekleniyor…':transcript))),
  const Spacer(),FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:magenta),onPressed:finish,icon:const Icon(Icons.stop),label:const Padding(padding:EdgeInsets.all(14),child:Text('Toplantıyı Bitir')))
 ])));
}
class PlanetPainter extends CustomPainter{final double t,level;PlanetPainter(this.t,this.level);@override void paint(Canvas c,Size s){final center=Offset(s.width/2,s.height/2),r=72.0;final glow=Paint()..color=cyan.withValues(alpha:.15)..maskFilter=const MaskFilter.blur(BlurStyle.normal,22);c.drawCircle(center,r+12,glow);final p=Paint()..shader=const LinearGradient(colors:[Color(0xFF102D5B),cyan,magenta]).createShader(Rect.fromCircle(center:center,radius:r));c.drawCircle(center,r,p);final line=Paint()..color=Colors.white.withValues(alpha:.25)..style=PaintingStyle.stroke..strokeWidth=1.2;for(int i=-2;i<=2;i++){c.drawOval(Rect.fromCenter(center:center,width:r*2,height:r*(.25+i.abs()*.18)),line);}final orbit=Paint()..color=magenta.withValues(alpha:.65)..style=PaintingStyle.stroke..strokeWidth=1.4;c.save();c.translate(center.dx,center.dy);c.rotate(t*math.pi*2);c.drawOval(Rect.fromCenter(center:Offset.zero,width:210,height:95),orbit);c.drawCircle(Offset(105,0),4+(level.abs()%5),Paint()..color=lime);c.restore();}@override bool shouldRepaint(covariant PlanetPainter old)=>old.t!=t||old.level!=level;}

class ProcessingPage extends StatefulWidget{final String title;final List<String> people;final String transcript;const ProcessingPage({super.key,required this.title,required this.people,required this.transcript});@override State<ProcessingPage> createState()=>_ProcessingPageState();}
class _ProcessingPageState extends State<ProcessingPage>{int step=0;Timer? timer;@override void initState(){super.initState();timer=Timer.periodic(const Duration(milliseconds:650),(t){if(step>=4){t.cancel();Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ResultPage(title:widget.title,people:widget.people,transcript:widget.transcript)));}else{setState(()=>step++);}});}@override void dispose(){timer?.cancel();super.dispose();}@override Widget build(BuildContext c){final items=['Transkript hazır','Konular belirlendi','AI özeti hazırlanıyor','Kararlar ve aksiyonlar çıkarılıyor','Açık konular belirleniyor'];return Scaffold(appBar:AppBar(title:const Text('Toplantı İşleniyor')),body:Padding(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const SizedBox(height:30),const Text('Toplantınız Analiz Ediliyor',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:25),...items.asMap().entries.map((e)=>ListTile(contentPadding:EdgeInsets.zero,leading:Icon(e.key<step?Icons.check_circle:e.key==step?Icons.autorenew:Icons.radio_button_unchecked,color:e.key<step?lime:cyan),title:Text(e.value))),const Spacer(),const FilledButton(onPressed:null,child:Text('🔒 Transkripti Gönder'))])));}}

class ResultPage extends StatelessWidget{final String title;final List<String> people;final String transcript;const ResultPage({super.key,required this.title,required this.people,required this.transcript});
 String get summary=>transcript.trim().isEmpty?'Transkript oluşmadı.':'Canlı transkript tamamlandı. AI sağlayıcısı bağlandığında özet, karar, aksiyon ve açık konular bu metinden üretilecek.';
 Future<void> export(BuildContext context)async{final dir=await getTemporaryDirectory();final safe=title.replaceAll(RegExp(r'[^a-zA-Z0-9ğüşöçıİĞÜŞÖÇ _-]'),'').replaceAll(' ','_');final f=File('${dir.path}/${safe.isEmpty?'Toplanti':safe}_${DateTime.now().day}-${DateTime.now().month}-${DateTime.now().year}.txt');await f.writeAsString('''NOPEn V0.4\nTOPLANTI: $title\nKATILIMCILAR: ${people.join(', ')}\n\nAI ÖZETİ\n$summary\n\nALINAN KARARLAR\nAI analizi bekleniyor.\n\nAKSİYONLAR\nAI analizi bekleniyor.\n\nAÇIK KONULAR\nAI analizi bekleniyor.\n\nTAM TRANSKRİPT\n$transcript\n''');await SharePlus.instance.share(ShareParams(files:[XFile(f.path)],subject:'$title - NoPen Toplantı Sonucu'));}
 Widget sec(String t,IconData i,String x,Color col)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(i,color:col),const SizedBox(width:8),Text(t,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold))]),const SizedBox(height:9),Text(x)])));
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Toplantı Sonucu')),body:ListView(padding:const EdgeInsets.all(16),children:[Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),if(people.isNotEmpty)Text(people.join(' • '),style:const TextStyle(color:Colors.white54)),const SizedBox(height:12),sec('AI ÖZETİ',Icons.auto_awesome,summary,cyan),sec('ALINAN KARARLAR',Icons.gavel,'AI bağlantısı sonrası otomatik doldurulur.',lime),sec('AKSİYONLAR',Icons.task_alt,'Görev • Sorumlu • Termin • Durum',magenta),sec('AÇIK KALAN KONULAR',Icons.warning_amber,'Karara bağlanmayan konular burada gösterilir.',Colors.orangeAccent),sec('TAM TRANSKRİPT',Icons.notes,transcript.isEmpty?'Transkript yok.':transcript,Colors.lightBlueAccent),const SizedBox(height:8),FilledButton.icon(onPressed:()=>export(context),icon:const Icon(Icons.email_outlined),label:const Text('Transkripti Gönder'))]));}

class MeetingsPage extends StatelessWidget{const MeetingsPage({super.key});@override Widget build(BuildContext c)=>const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[PageTitle('Toplantılar',sub:'Geçmiş toplantılar ve sonuçları'),Padding(padding:EdgeInsets.all(20),child:Text('Henüz kayıtlı toplantı yok.',style:TextStyle(color:Colors.white54)))]);}
class ActionsPage extends StatelessWidget{const ActionsPage({super.key});@override Widget build(BuildContext c)=>const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[PageTitle('Aksiyonlar',sub:'Açık ve tamamlanan işler'),Padding(padding:EdgeInsets.all(20),child:Text('AI analiziyle çıkarılan aksiyonlar burada toplanacak.',style:TextStyle(color:Colors.white54)))]);}
class AskAiPage extends StatelessWidget{const AskAiPage({super.key});@override Widget build(BuildContext c)=>ListView(children:[const PageTitle('Toplantıya Sor',sub:'Toplantı kayıtlarında AI ile ara'),Padding(padding:const EdgeInsets.all(20),child:TextField(decoration:InputDecoration(hintText:'Örn. İstanbul deposu hakkında ne karar verdik?',prefixIcon:Icon(Icons.search),border:OutlineInputBorder()))) ]);}
class SettingsPage extends StatelessWidget{const SettingsPage({super.key});@override Widget build(BuildContext c)=>ListView(children:[const PageTitle('Ayarlar'),const ListTile(leading:Icon(Icons.mail_outline,color:cyan),title:Text('Microsoft Outlook'),subtitle:Text('Bağlı değil • OAuth 2.0 / Microsoft Graph'),trailing:Icon(Icons.chevron_right)),const ListTile(leading:Icon(Icons.calendar_month),title:Text('Outlook Takvimi'),subtitle:Text('İzin: Calendars.Read')),const ListTile(leading:Icon(Icons.send_outlined),title:Text('E-posta Gönderimi'),subtitle:Text('İzin: Mail.Send')),const ListTile(leading:Icon(Icons.mic_none),title:Text('Ses Kaydı Saklama'),subtitle:Text('Kapalı • Ses yalnızca canlı transkript için işlenir')),const ListTile(leading:Icon(Icons.animation),title:Text('Animasyon Kalitesi'),subtitle:Text('Otomatik'))]);}
