# NoPen V0.4

**Toplantı Biter. Sonuç Kalır.**

V0.4 kapsamı: toplantı hazırlığı, katılımcılar, ses dosyası saklamadan canlı speech-to-text, canlı uzay/Dünya animasyonu, işleme ekranı, AI sonuç bölümleri, TXT dışa aktarma, Toplantılar/Aksiyonlar/AI/Ayarlar navigasyonu ve Microsoft Outlook entegrasyonu için arayüz/mimari hazırlığı.

## Microsoft Graph
Hedef yetkiler:
- `Calendars.Read` — Outlook takvimindeki toplantıları okumak.
- `Mail.Send` — NoPen sonucunu kullanıcının Microsoft hesabından göndermek.

> Önemli: OAuth bağlantısının gerçekten çalışması için Microsoft Entra App Registration oluşturulmalı ve gerçek **Application (Client) ID**, tenant/account politikası ve Android redirect URI yapılandırılmalıdır. V0.4 kaynak paketi bu kimlik bilgilerini uydurmaz veya APK içine client secret gömmez. Şu an Outlook ekranları ve izin modeli hazırdır; gerçek Microsoft hesabı oturumu App Registration bilgileri girildiğinde bağlanacaktır.

## AI
V0.4 sonuç ekranları AI özeti/kararlar/aksiyonlar/açık konular için hazırdır. Gerçek AI sağlayıcı anahtarı/backend yapılandırılmadığı için uygulama sahte AI sonucu üretmez; ilgili alanlar bağlantı beklediğini açıkça gösterir.

## Build
Codemagic `codemagic.yaml` ile `flutter: stable` kullanır ve Android release APK üretir. Android package hedefi `com.nopen.meeting`, uygulama adı `NoPen` olarak oluşturulur.

## V0.4 dependency refresh — 27 Sep 2026
Codemagic uses the current Flutter `stable` channel on Ubuntu 24.04. Dependency constraints were refreshed against current stable pub.dev releases: speech_to_text 7.5.0, permission_handler 13.0.2, share_plus 13.3.0, path_provider 2.1.6, shared_preferences 2.5.5, flutter_appauth 12.1.0, flutter_secure_storage 11.2.0, http 1.6.0, cupertino_icons 1.0.9 and flutter_lints 6.0.0.

Microsoft integration target: OAuth 2.0 / OIDC authorization code with PKCE (public mobile client), Microsoft Graph delegated permissions `Calendars.Read` and `Mail.Send`. Do not embed a client secret in the APK. The real Entra Client ID/redirect configuration must be supplied after App Registration.

Note: `speech_to_text` is suitable for platform speech recognition and short/command-style sessions; production-grade continuous long-meeting transcription should use a dedicated streaming transcription service behind the same UI/service abstraction.
