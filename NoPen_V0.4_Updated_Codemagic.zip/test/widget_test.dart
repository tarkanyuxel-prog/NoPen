import 'package:flutter_test/flutter_test.dart';
import 'package:nopen/main.dart';

void main() {
  testWidgets('NoPen ana ekranı açılır', (tester) async {
    await tester.pumpWidget(const NoPenApp());
    expect(find.text('NoPen'), findsOneWidget);
    expect(find.text('Toplantı Biter. Sonuç Kalır.'), findsOneWidget);
  });
}
